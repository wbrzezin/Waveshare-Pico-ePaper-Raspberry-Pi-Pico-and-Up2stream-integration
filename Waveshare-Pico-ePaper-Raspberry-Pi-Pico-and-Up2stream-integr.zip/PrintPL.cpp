/******************************************************************************
 * @file    PrintPL.cpp
 * @brief   Obsługa polskich znaków dla klasy Print.
 ******************************************************************************/

#include "PrintPL.h"

/**
 * @brief Tymczasowa implementacja funkcji.
 *
 * Na obecnym etapie funkcja przekazuje wszystkie znaki bez zmian.
 * Obsługa UTF-8 zostanie dodana w kolejnych krokach.
 */
/**
 * @brief Wyświetla tekst.
 *
 * Aktualnie funkcja rozpoznaje znaki ASCII oraz przygotowuje
 * strukturę do późniejszej obsługi sekwencji UTF-8.
 */
void printPL(Print &out, const char *text)
{
    while (*text)
    {
        uint8_t c = (uint8_t)*text++;

        /* Znaki ASCII (0x00...0x7F) przekazujemy bez zmian. */
        if (c < 0x80)
        {
            out.write(c);
        }
        else
        {
            /* Obsługa UTF-8 zostanie dodana w kolejnym kroku. */
        }
    }
}